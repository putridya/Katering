<?php require_once("koneksi2.php");
    if (!isset($_SESSION)) {
        session_start();
    } ?>
<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<title>DWI Camera Shop | Toko Kamera Online telengkap dan terpercaya di Malang</title> 
	<meta name="description" content="Kamera, Malang, terlengkap, information, technology, murah"/>
	<meta name="keywords" content="Kamera, Murah, Malang, Baru, terlengkap, harga, terjangkau" />
	<meta name="author" content="DWI Camera Shop"/>

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<meta property="og:title" content=""/>
	<meta property="og:description" content=""/>
	<meta property="og:type" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:image" content=""/>

    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">

</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="logo span3">	
					<a class="brand" href="#"><img src="img/logogua.png" alt="Logo"></a>		
				</div>
				<div class="span8">
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<div class="nav-collapse collapse">
			            		<ul class="nav">
			              			<li><a href="index.php">Home</a></li>
			              			<li><a href="produk.php">Produk Kami</a></li>
                                    <li class="active"><a href="detail.php">Keranjang</a></li>
			              			<li class="dropdown">
			                			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Login <b class="caret"></b></a>
			                			<ul class="dropdown-menu">
			                  				<li><a href="index.html">Admin</a></li>
			                  				<li><a href="index.php">Konsumen</a></li>
			                			</ul>
			              			</li>
			            		</ul>
			          		</div>
			        	</div>
			      	</div>
			      	<div class="logo span1">
			      	</div>
				</div>
			</div>
		</div>
	</header>
	<div id="page-title">
		<div id="page-title-inner">
			<div class="container">
			<div class=span8>
				<h2><i></i>Keranjang</h2>
			</div>
			<div class=span3>
				<form name="formcari" method="post" action="search_exe.php">
				<table width="330" border="0" align="center" cellpadding="0">
				<tr>
				<td> <input class="form-control" placeholder="Search for..." type="text" name="name"> </td>
				<td> <input class="btn btn-success btn-large"  type="SUBMIT" name="SUBMIT" id="SUBMIT" value="search" > </td>
				</tr>
				</table>
				</form>
			</div>
			</div>
		</div>
	</div>
	<div id="wrapper">
		<div class="container">
            <div class="title"><h3>Detail Keranjang Belanja</h3></div>
				<table class="table table-hover table-condensed">
					<tr>
						<th><center>No Pembelian</center></th>
	                    <th><center>Nama Pembeli</center></th>
						<th><center>Nama Barang</center></th>
						<th><center>Harga</center></th>
						<th><center>Opsi</center></th>
					</tr>
					<?php       
					$i = 1;           
					$query = mysqli_query($koneksi, "SELECT * from barang as b inner join transaksi as t on b.br_id = t.br_id");
					while($data = mysqli_fetch_array($query)){
						echo "<tr>";
						echo "<th><center>$i</center></th>";
						echo "<th><center>$data[nama]</center></th>";
						echo "<th><center>$data[br_nm]</center></th>";
						echo "<th><center>$data[br_hrg]</center></th>";
						echo "<th>
					<center>
						<a href='detailtrans.php?barang=$data[id]' class='btn btn-xs btn-success'>Detail</a> 
						<a href='edittrans.php?barang=$data[id]' class='btn btn-xs btn-warning'>Edit</a> 
						<a href='deletetrans.php?barang=$data[id]'  class='btn btn-xs btn-danger'>Hapus</a> 
					</center>
					</td>";           
					echo "</tr>";

			$i++;
			} 
			?>
			</table>
			<br><br><br>
			<h2>Point Plus Dari Kami</h2>
			<br>
			<div class="row">
				<div class="icons-box-vert-container">
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-ok ico-color circle-color big"></i>
							<div class="icons-box-vert-info">
								<h3>Kemudahan Berbelanja</h3>
								<p>Dapatkan kemudahan berbelanja di DWI Camera Shop, Kami menyediakan berbagai jenis Camera.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-cup  ico-white circle-color-full big-color"></i>
							<div class="icons-box-vert-info">
								<h3>Juara Pengiriman Delivery</h3>
								<p>Dapatkan kemudahan pengiriman barang ke rumah anda dengan minimal belanja 1 Juta radius 10km dari kantor kami.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-ipad ico-color circle-color big"></i>
							<div class="icons-box-vert-info">
								<h3>Berbelanja Dengan Gadget</h3>
								<p>Anda bisa memesan produk kami melalui gadget kesayangan anda, belanja di DWI Camera Shop praktis dan mudah.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-thumbs-up  ico-white circle-color-full big-color"></i>
							<div class="icons-box-vert-info">
								<h3>Sosial Media</h3>
								<p>Follow twitter dan fan page facebook kami untuk mendapatkan update promo special setiap harinya.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>			
			<hr>
		</div>
	</div>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="span4">
					<h3>Tentang Kami</h3>
					<p>
						DWI Camera Shop adalah toko online yang menjual berbagai jenis kamera mulai dari kamera Digital, DSLR, GO PRO, dan masih banyak yang lainnya. Sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa, fotografer Amatir maupun Profesional.
					</p>						
				</div>
				<div class="span4">
					<h3>Alamat Kami</h3>
					Perum. Griya Santa blok G no.318<br />
                    Telp : 081357646083<br />
                    Email : <a href="dwiprasetyowidaryanto@gmail.com">dwiprasetyowidaryanto@gmail.com</a> / <a href="dwi.p22222@yahoo.co.id">dwi.p22222@yahoo.co.id</a>
				</div>
				<div class="span4">
					<h3>Follow Us!</h3>
					<ul class="social-grid">
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-facebook">
											<a href="http://facebook.com"></a>
										</div>
										<div class="social-info-back social-facebook-hover">
											<a href="http://facebook.com"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
				</div>				
			</div>
		</div>
	</div>
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script defer="defer" src="js/custom.js"></script>
\</body>
</html>