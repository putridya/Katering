<?php require_once("koneksi2.php");
    if (!isset($_SESSION)) {
        session_start();
    } ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>FoodShop | Food Shop terlengkap dan ternama di Kota Malang</title> 
	<meta name="description" content="Makanan, Malang, terlengkap, information, technology, murah"/>
	<meta name="keywords" content="Makanan, Murah, Malang, Baru, terlengkap, harga, terjangkau" />
	<meta name="author" content="GotYA"/>
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: Facebook Open Graph -->
	<meta property="og:title" content=""/>
	<meta property="og:description" content=""/>
	<meta property="og:type" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:image" content=""/>
	<!-- end: Facebook Open Graph -->

    <!-- start: CSS --> 
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">

</head>
<body>
    
	<!--start: Header -->
	<header>
		
		<!--start: Container -->
		<div class="container">
			
			<!--start: Row -->
			<div class="row">
					
				<!--start: Logo -->
				<div class="logo span3">
						
					<a class="brand" href="#"><img src="img/logo.png" alt="Logo"></a>
						
				</div>
				<!--end: Logo -->
					
				<!--start: Navigation -->
				<div class="span8">
					
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<div class="nav-collapse collapse">
			            		<ul class="nav">
			              			<li><a href="index.php">Beranda</a></li>
			              			<li class="active"><a href="produk.php">Menu Makanan</a></li>
                                    <li><a href="detail.php">Keranjang</a></li>
			              			<li class="dropdown">
			                			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Login <b class="caret"></b></a>
			                			<ul class="dropdown-menu">
			                  				<li><a href="index.html">Admin</a></li>
			                  				<li><a href="index.php">Konsumen</a></li>
			                  				<!--<li class="divider"></li>
			                  				<li class="nav-header">Nav header</li>
			                  				<li><a href="#">Separated link</a></li>
			                  				<li><a href="#">One more separated link</a></li>-->
			                			</ul>
			              			</li>
			            		</ul>
			          		</div>
			        	</div>
			      	</div>

			      	<div class="logo span1">
			      	</div>
					
				</div>	
					
			</div>

		</div>		
			
	</header>

	<div id="page-title">
		<div id="page-title-inner">
			<div class="container">
			<div class=span8>
				<h2><i></i>Menu Makanan</h2>
			</div>
			<div class=span3>
				<form name="formcari" method="post" action="search_exe.php">
				<table width="330" border="0" align="center" cellpadding="0">
				<tr>
				<td> <input class="form-control" placeholder="Search for..." type="text" name="name"> </td>
				<td> <input class="btn btn-success btn-large"  type="SUBMIT" name="SUBMIT" id="SUBMIT" value="search" > </td>
				</tr>
				</table>
				</form>
			</div>
			</div>
		</div>
	</div>

	<div id="wrapper">
				
    	<div class="container"> 
            
      		<div class="row">
	<?php
                    $sql = mysqli_query($koneksi, "SELECT * FROM barang ORDER BY br_id DESC");
	if(mysqli_num_rows($sql) == 0){
		echo "Tidak ada produk!";
	}else{
		while($data = mysqli_fetch_assoc($sql)){
                    ?>
        		<div class="span4">
          			<div class="icons-box">
                        <div class="title"><h3><?php echo $data['br_nm']; ?></h3></div>
                        <img src="<?php echo $data['br_gbr']; ?>" />
						<div><h3>Rp <?php echo number_format($data['br_hrg'],2,",",".");?></h3></div>
						<div class="clear"><a href="detailproduk.php?hal=detailbarang&kd=<?php echo $data['br_id'];?>" class="btn btn-lg btn-danger">Detail</a> <a href="detailproduk.php?hal=detailbarang&kd=<?php echo $data['br_id'];?>" class="btn btn-lg btn-success">Beli &raquo;</a></div>

                    </div>
        		</div>
                <?php   
              }
              }
              
              ?>
      		</div>
				</div>	
				
					
				</div>
				
			</div>
			<!--end: Row-->
	
		</div>
		<!--end: Container-->
		<br><br><br>		
		<!-- start: Footer -->
	<div id="footer">
		
		<!-- start: Container -->
		<div class="container">
			
			<!-- start: Row -->
			<div class="row">

				<!-- start: About -->
				<div class="span4">
					
					<h3>Tentang Kami</h3>
					<p>
						GotYA adalah toko makanan online yang menjual berbagai jenis makanan Indonesia mulai dari masakan Jawa, Masakan Bali, Masakan Sumatra, Masakan Kalimantan dan masih banyak yang lainnya.
					</p>
						
				</div>
				<!-- end: About -->

				<!-- start: Photo Stream -->
				<div class="span4">
					
					<h3>Alamat Kami</h3>
                    Telp : 087819551118<br />
                    Email : <a href="ohm.asyukron@gmail.com">ohm.asyukron@gmail.com</a> / <a href="GotYA">GotYA</a>
				</div>
				<!-- end: Photo Stream -->

				<div class="span4">
				
					<!-- start: Follow Us -->
					<h3>Follow Us!</h3>
					<ul class="social-grid">
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-facebook">
											<a href="http://facebook.com"></a>
										</div>
										<div class="social-info-back social-facebook-hover">
											<a href="http://facebook.com"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
						
				
				</div>
				
			</div>	
			
		</div>

	</div>
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script def src="js/custom.js"></script>

</body>
</html>	