<?php require_once("koneksi2.php");
    if (!isset($_SESSION)) {
        session_start();

		$_SESSION['card'];
       
    } 
 		
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
	<title>FoodShop | Food Shop terlengkap dan ternama di Kota Malang</title> 
	<meta name="description" content="Makanan, Malang, terlengkap, information, technology, murah"/>
	<meta name="keywords" content="Makanan, Murah, Malang, Baru, terlengkap, harga, terjangkau" />
	<meta name="author" content="GotYA"/>

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<meta property="og:title" content=""/>
	<meta property="og:description" content=""/>
	<meta property="og:type" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:image" content=""/>
 
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
	
</head>
<body>
	<header>
		<div class="container">
			<div class="row">
				<div class="logo span3">
					<a class="brand" href="#"><img src="img/logo.png" alt="Logo"></a>
				</div>
				<div class="span8">
					<div class="navbar navbar-inverse">
			    		<div class="navbar-inner">
			          		<div class="nav-collapse collapse">
			            		<ul class="nav">
			              			<li class="active"><a href="index.php">Home</a></li>
			              			<li><a href="produk.php">Produk Kami</a></li>
                                    <li><a href="detail.php">Keranjang</a></li>
			              			<li class="dropdown">
			                			<a href="#" class="dropdown-toggle" data-toggle="dropdown">Login <b class="caret"></b></a>
			                			<ul class="dropdown-menu">
			                  				<li><a href="index.html">Admin</a></li>
			                  				<li><a href="index.php">Konsumen</a></li>
			                			</ul>
			              			</li>
			            		</ul>
			          		</div>
			        	</div>
			      	</div>
			      	<div class="logo span1">
			      	</div>
				</div>
			</div>
		</div>
	</header>
	<div id="page-title">
		<div id="page-title-inner">
			<div class="container">
			<div class=span8>
				<h2><i></i>Produk Kami</h2>
			</div>
			<div class=span3>
				<form name="formcari" method="post" action="search_exe.php">
				<table width="330" border="0" align="center" cellpadding="0">
				<tr>
				<td> <input class="form-control" placeholder="Search for..." type="text" name="name"> </td>
				<td> <input class="btn btn-success btn-large"  type="SUBMIT" name="SUBMIT" id="SUBMIT" value="search" > </td>
				</tr>
				</table>
				</form>
			</div>
			</div>
		</div>
	</div>
	<div id="wrapper">
    	<div class="container">              
    	<div class="title"><h3>Transaksi Anda</h3></div>
        <div class="hero-unit">
        	<?php  
            	if(isset($_POST['transaksi']))
	            	{
					 	$id = $_GET['kd'];
					 	$nama = $_POST['nama'];
					 	$alamat  =$_POST['alamat'];
					 	$pos = $_POST['pos'];
					 	$kota =  $_POST['kota'];
					 	$telp = $_POST['telp'];
					 	$norek = $_POST['norek'];
					 	$narek = $_POST['narek'];
					 	$bank = $_POST['bank'];

					 	if ( empty($nama) || empty($nama) || empty($alamat) || empty($pos) || empty($kota) || empty($norek) || empty($narek) || empty($bank))
						{
							echo "<strong>Data harus di isi.</strong>";
						}else {
							if (empty($error)){
							echo "<p>Terima kasih data sudah di simpan</p>";
							}
							{

							}

						}
	 	
	 					$query1 = mysqli_query($koneksi,"insert into transaksi values (null,'$nama','$alamat','$pos','$kota','$telp','$norek','$narek','$bank','$id')");
					}

            ?>
        	
        	<form action="" method="POST">
            	<table class="table table-hover table-condensed">
               	    <tr>
                    	<th><center>Nama</center></th>
                    	<th><input type="text" name="nama"></th>
                    </tr>
                    <tr>
						<th><center>Alamat</center></th>
						<th><input type="text" name="alamat"></th>
					</tr>
					<tr>
						<th><center>Kode Pos</center></th>
						<th><input type="text" name="pos"></th>
					</tr>
					<tr>
						<th><center>Kota</center></th>
						<th><input type="text" name="kota"></th>
					</tr>
					<tr>
						<th><center>No Telp</center></th>
						<th><input type="text" name="telp"></th>
					</tr>
					<tr>
						<th><center>No Rek</center></th>
						<th><input type="text" name="norek"></th>
					</tr>
					<tr>
						<th><center>Nama Rek</center></th>
						<th><input type="text" name="narek"></th>
					</tr>
					<tr>
						<th><center>Bank</center></th>
						<th><input type="text" name="bank"></th>
					</tr>
					<tr>
					<th></th>
				 		<th><input type="submit" name="transaksi" value="Beli >>"></a></th>
				 	</tr>
			</form>
        
      		<div class="row">
            <div class="col-sm-6">
                <?php                  
					$query = mysqli_query($koneksi, "SELECT * FROM barang WHERE br_id='$_GET[kd]'");
					$data  = mysqli_fetch_array($query);
				?>
                    
                <div class="hero-unit" style="margin-left: 20px;">
                    <table>
                    	<tr>
                        	<td rowspan="7"><img src="<?php echo $data['br_gbr']; ?>" /></td>
                        </tr>
                        <tr>
                        	<td colspan="4"><div class="title"><h3><?php echo $data['br_nm']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td size="200"><h3>Harga</h3></td>
                        <td><h3>:</h3></td>
						<td><div><h3>Rp <?php echo number_format($data['br_hrg'],2,",",".");?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Stock</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3><?php if ($data['br_stok'] >= 1){
	                           echo '<strong style="color: blue;">In Stock</strong>';	
                                } else {
	                           echo '<strong style="color: red;">Out Of Stock</strong>';	
                                }; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Satuan</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3><?php echo $data['br_satuan']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td><h3>Keterangan</h3></td>
                        <td><h3>:</h3></td>
                        <td><div><h3><?php echo $data['ket']; ?></h3></div></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td></td>
                        <td></td>
						
                        </tr>
     
                    </table>
                </div>

			<br><br><br>
			<h2>Point Plus Dari Kami</h2>
			<br>

			<div class="row">
				<div class="icons-box-vert-container">
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-ok ico-color circle-color big"></i>
							<div class="icons-box-vert-info">
								<h3>Kemudahan Berbelanja</h3>
								<p>Dapatkan kemudahan berbelanja di Black Camera Shop, Kami menyediakan berbagai jenis Camera.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-cup  ico-white circle-color-full big-color"></i>
							<div class="icons-box-vert-info">
								<h3>Juara Pengiriman Delivery</h3>
								<p>Dapatkan kemudahan pengiriman barang ke rumah anda dengan minimal belanja 1 Juta radius 10km dari kantor kami.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-ipad ico-color circle-color big"></i>
							<div class="icons-box-vert-info">
								<h3>Berbelanja Dengan Gadget</h3>
								<p>Anda bisa memesan produk kami melalui gadget kesayangan anda, belanja di Black Camera Shop praktis dan mudah.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
					<div class="span6">
						<div class="icons-box-vert">
							<i class="ico-thumbs-up  ico-white circle-color-full big-color"></i>
							<div class="icons-box-vert-info">
								<h3>Sosial Media</h3>
								<p>Follow twitter dan fan page facebook kami untuk mendapatkan update promo special setiap harinya.</p>
							</div>
							<div class="clear"></div>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			<hr>
		</div>
	</div>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="span4">
					<h3>Tentang Kami</h3>
					<p>
						Black Camera Shop adalah toko online yang menjual berbagai jenis kamera mulai dari kamera Digital, DSLR, GO PRO, dan masih banyak yang lainnya. Sasaran kami semua kalangan baik muda maupun tua, mulai dari anak - anak dan orang dewasa, fotografer Amatir maupun Profesional.
					</p>
				</div>
				<div class="span4">
					<h3>Alamat Kami</h3>
					Perum. Graha Mentari blok AF no.24 Bangkalan<br />
                    Telp : 081357646083<br />
                    Email : <a href="ohm.asyukron@gmail.com">oh,.asyukron@gmail.com</a> / <a href="@blqckaron">blqckaron</a>
				</div>
				<div class="span4">
					<h3>Follow Us!</h3>
					<ul class="social-grid">
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-twitter">
											<a href="http://twitter.com"></a>
										</div>
										<div class="social-info-back social-twitter-hover">
											<a href="http://twitter.com"></a>
										</div>	
									</div>
								</div>
							</div>
						</li>
						<li>
							<div class="social-item">				
								<div class="social-info-wrap">
									<div class="social-info">
										<div class="social-info-front social-facebook">
											<a href="http://facebook.com"></a>
										</div>
										<div class="social-info-back social-facebook-hover">
											<a href="http://facebook.com"></a>
										</div>
									</div>
								</div>
							</div>
						</li>
				</div>
			</div>
		</div>
	</div>
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script src="js/jquery.cslider.js"></script>
<script src="js/slider.js"></script>
<script def src="js/custom.js"></script>

</body>
</html>	