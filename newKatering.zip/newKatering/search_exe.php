<?php
include "koneksi.php";
$name= $_POST['name']; //get the nama value from form
$result = mysql_query("SELECT * FROM barang WHERE br_nm LIKE '%".$name."%'"); //execute the query $q
echo "<center>";
echo "<h2> Hasil Searching </h2>";
echo "<table border='1' cellpadding='5' cellspacing='8'>";
echo "
<tr bgcolor='orange'>
<td>Nama Barang</td>
<td>Harga Barang</td>
<td>Keterangan</td>
</tr>";
while ($row = mysql_fetch_row($result)) {  //fetch the result from query into an array
echo "
<tr>
<td>".$row[1]."</td>
<td>Rp.".$row[3]."</td>
<td>".$row[7]."</td>
</tr>";
}
echo "</table>";
?>
