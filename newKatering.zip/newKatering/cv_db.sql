-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2018 at 01:13 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cv_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `br_id` int(6) NOT NULL,
  `br_nm` varchar(50) NOT NULL,
  `br_item` int(4) NOT NULL,
  `br_hrg` int(10) NOT NULL,
  `br_stok` int(9) NOT NULL,
  `br_satuan` varchar(20) NOT NULL,
  `br_gbr` varchar(100) NOT NULL,
  `ket` varchar(250) NOT NULL,
  `br_sts` varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`br_id`, `br_nm`, `br_item`, `br_hrg`, `br_stok`, `br_satuan`, `br_gbr`, `ket`, `br_sts`) VALUES
(1, 'Canon EOS 500D', 1, 5500000, 12, 'Pcs', 'gambar/canon500d.jpg', 'DSLR - dengan Lens, 15MP\r\nISO100-3200\r\n30-1/4000', 'Y'),
(2, 'Canon EOS 600D', 1, 5400000, 24, 'Pcs', 'gambar/canon600d.jpg', 'DSLR - dengan Lens, 18MP\r\nISO100-6400\r\n30-1/4000', 'Y'),
(3, 'Canon EOS 1000D', 1, 4000000, 30, 'Pcs', 'gambar/canon1000d.jpg', 'DSLR - dengan Lens, 10.1MP\r\nISO100-1600\r\n30-1/4000', 'Y'),
(4, 'Canon EOS 1100D', 1, 3400000, 20, 'Pcs', 'gambar/canon1100.jpg', 'DSLR - dengan Lens, 12.2MP\r\nISO100-3200\r\n30-1/4000', 'Y'),
(5, 'Nikon DSLR D3100', 1, 4875000, 30, 'Pcs', 'gambar/NikonD3100.jpg', 'DSLR - dengan Lens, 14.2MP\r\nISO100-3200\r\n30-1/4000', 'Y'),
(6, 'Nikon DSLR D3200', 1, 4700000, 20, 'Pcs', 'gambar/nikond3200.jpg', 'DSLR - dengan Lens, 24.2MP\r\n100-6400ISO\r\n1/1/4000', 'Y'),
(7, 'Nikon DSLR D7000', 1, 8000000, 20, 'Pcs', 'gambar/nikond7000.jpg', 'DSLR - dengan Lens, 16.2MP\r\nISO100-6400\r\n30-1/8000', 'Y'),
(8, 'GO PRO Hero 4 Black', 1, 7150000, 12, 'Pcs', 'gambar/black.jpg', 'GO PRO Hero 4 Black New', 'Y'),
(9, 'GO PRO Hero 4 Silver', 1, 5500000, 20, 'Pcs', 'gambar/silver.jpg', 'GO PRO Hero 4 Silver New', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id_username` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id_username`, `username`, `nama`, `password`) VALUES
(8, '[removed]dwiprasetyo[remo', 'dwiprasetyo', '25d55ad283aa400af464c76d713c07ad'),
(9, '[removed]robiab[removed]', 'robiab', '25d55ad283aa400af464c76d713c07ad'),
(10, '<IMG>', 'abdilah', '25d55ad283aa400af464c76d713c07ad'),
(11, 'javascript', 'dolljj', '25d55ad283aa400af464c76d713c07ad'),
(12, 'select * from signup', 'suyanti', '22d7fe8c185003c98f97e5d6ced420c7'),
(13, '"test"', 'suyanti', '25d55ad283aa400af464c76d713c07ad'),
(14, 'IMG SRC="[removed]alert&#', 'suyanti', '22d7fe8c185003c98f97e5d6ced420c7');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `kode_pos` varchar(5) NOT NULL,
  `kota` varchar(20) NOT NULL,
  `no_telp` varchar(12) NOT NULL,
  `no_rekening` varchar(12) NOT NULL,
  `nama_rekening` varchar(20) NOT NULL,
  `bank` varchar(20) NOT NULL,
  `br_id` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `nama`, `alamat`, `kode_pos`, `kota`, `no_telp`, `no_rekening`, `nama_rekening`, `bank`, `br_id`) VALUES
(8, 'dfhfdh', 'hgfh', '45345', 'ryrh', '6463', '46346', 'fdhfd', 'fhdff', 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`br_id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id_username`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `br_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id_username` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
