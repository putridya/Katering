<?php require_once("koneksi2.php");

$hapus = mysqli_query($koneksi , "delete from transaksi where id='$_GET[barang]'");
echo "
		<script>
			window.location='detail.php'
		</script>
";

?>