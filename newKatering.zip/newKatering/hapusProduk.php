<?php require_once("koneksi2.php");
	$barang = $_GET['barang'];
	$hapus = mysqli_query($koneksi , "delete from barang where br_id ='$barang'");
	if($hapus){
		echo "<script>
			alert('Data Barang telah dihapus')
			window.location='produkAdmin.php'
		</script>";
	}else{
		echo"<script>
			alert('Data Barang gagal dihapus')
			window.location='produkAdmin.php'
		</script>";
	}

?>